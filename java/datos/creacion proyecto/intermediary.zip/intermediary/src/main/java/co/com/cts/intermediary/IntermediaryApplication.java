package co.com.cts.intermediary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntermediaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntermediaryApplication.class, args);
	}

}

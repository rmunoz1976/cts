package co.com.cts.intermediary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntermediaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
